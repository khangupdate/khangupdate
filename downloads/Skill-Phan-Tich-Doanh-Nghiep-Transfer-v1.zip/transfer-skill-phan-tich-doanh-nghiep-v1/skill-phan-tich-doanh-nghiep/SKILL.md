---
name: phan-tich-doanh-nghiep
description: Phân tích toàn diện một doanh nghiệp từ tên công ty hoặc website, bằng nguồn công khai và ngôn ngữ dễ hiểu cho Owner/sếp. Tự dựng bản đồ công ty, sản phẩm, cách kiếm tiền, cách mở rộng, thương hiệu, khoa học/pháp lý khi liên quan, điểm mạnh, điểm cần kiểm tra, dữ liệu còn thiếu và câu hỏi cần hỏi thêm. Khi Owner yêu cầu landing/link/repo hoặc kích hoạt Skill theo chế độ đầy đủ, thích nghi thiết kế theo ngôn ngữ thương hiệu của website, tạo landing report, kiểm tra bản web đang chạy và chỉ trả DONE khi link thật hoạt động. Không dùng để định giá đầu tư, kết luận vi phạm pháp luật, chẩn đoán y khoa, hoặc thay thế kiểm toán/kiểm tra hồ sơ nội bộ.
---

# skill Phân Tích Doanh Nghiệp

**Technical ID:** `phan-tich-doanh-nghiep`
**Lifecycle:** CANDIDATE V1 — Owner-authorized explicit use; cần thêm live A/B evidence trước ACTIVE promotion.
**Owner:** PROJECT_OWNER

## Mục tiêu

Biến một đầu vào rất ngắn như tên công ty hoặc website thành một hồ sơ doanh nghiệp có thể dùng ngay để hiểu:

- công ty là ai;
- đang bán gì;
- tiền đến từ đâu;
- cách họ kéo khách, giữ khách và mở rộng;
- ai đang vận hành / sở hữu / đại diện khi thông tin công khai cho phép;
- phần nào là dữ kiện, phần nào là doanh nghiệp tự nói, phần nào là nhận định;
- điều gì đang làm tốt;
- điều gì cần cẩn trọng;
- còn thiếu dữ liệu nào để hiểu sức khỏe doanh nghiệp thật;
- cần hỏi thêm gì nếu muốn hợp tác, đầu tư, học mô hình hoặc cạnh tranh.
## Khi nào dùng

Kích hoạt khi Owner nói theo các kiểu:

- “Dùng skill Phân Tích Doanh Nghiệp phân tích công ty X.”
- “Phân tích toàn bộ công ty này: <website>.”
- “Tìm hiểu doanh nghiệp X cho tôi, làm landing report.”
- “Mổ xẻ công ty X xem họ kiếm tiền thế nào.”
- “Phân tích đối thủ X từ đầu đến cuối.”
- “Làm hồ sơ doanh nghiệp X để tôi gửi sếp xem.”

Nếu Owner chỉ đưa tên công ty/website sau khi đã gọi rõ Skill này, coi đó là đủ đầu vào để bắt đầu.

## Không kích hoạt

Không dùng cho:

- tra cứu một thông tin đơn lẻ như mã số thuế, giá một sản phẩm, địa chỉ;
- viết bài PR hoặc hồ sơ giới thiệu doanh nghiệp theo giọng quảng cáo;
- chỉ nghiên cứu thị trường ngành mà không có doanh nghiệp mục tiêu;
- định giá cổ phiếu / khuyến nghị mua bán chứng khoán;
- kết luận pháp lý kiểu “công ty vi phạm” khi chưa có kết luận có thẩm quyền;
- kết luận hiệu quả y khoa chỉ từ quảng cáo hoặc một nghiên cứu không phù hợp;
- kiểm toán tài chính hoặc điều tra dữ liệu nội bộ khi chỉ có nguồn công khai.

## Hai chế độ đầu ra

### 1. LANDING_AND_PUBLISH — mặc định khi Owner gọi rõ Skill
Khi Owner nói “dùng skill Phân Tích Doanh Nghiệp” và đưa tên công ty/website, mặc định thực hiện trọn quy trình: nghiên cứu + landing + QA + repo public + link xem thật.

Việc gọi rõ Skill được xem là yêu cầu trực tiếp cho đầu ra chuẩn này. Nếu môi trường hiện tại không có quyền/công cụ publish, không được giả vờ đã xuất bản; phải trả artifact đã tạo và blocker thật.

### 2. REPORT_ONLY — chỉ khi Owner giới hạn phạm vi
Dùng khi Owner nói “chỉ báo cáo”, “chưa làm web”, “chưa publish”, “viết báo cáo trước”.

Owner có thể đổi chế độ bất kỳ lúc nào bằng câu ngắn, không cần nhắc lại toàn bộ quy trình.
## Luật cứng

1. **FACT != COMPANY_CLAIM != ANALYSIS.**
2. Không biến mục tiêu tương lai thành kết quả đã đạt.
3. Không biến số bài báo thành quy mô kinh doanh.
4. Không lấy lời khách hàng làm bằng chứng khoa học.
5. Không lấy nghiên cứu về một công nghệ chung để tự động chứng minh sản phẩm cụ thể.
6. Không lấy ngành nghề đăng ký để tự động suy ra quyền cấp chứng chỉ/giấy phép cụ thể.
7. Không suy doanh thu, lợi nhuận, số khách, số đại lý hoạt động nếu không có bằng chứng.
8. Mâu thuẫn nguồn phải được giữ lại và giải thích, không chọn nguồn thuận mắt.
9. Nguồn do doanh nghiệp tự đăng chỉ chứng minh “doanh nghiệp đang công bố điều này”.
10. Khi thiếu dữ liệu quan trọng, kết quả đúng là **CHƯA RÕ / CẦN HỎI THÊM**, không phải đoán.
11. Owner-facing copy phải tuân thủ `organization/OWNER_COMMUNICATION_STANDARD_V1.md`.
12. Từ khó phải được thay bằng tiếng Việt đời thường hoặc giải thích ngay trong cùng câu.
13. Thiết kế phải học ngôn ngữ thương hiệu, không sao chép nguyên website.
14. Repo/code đã sửa nhưng website chưa cập nhật thì **CHƯA DONE**.
15. DONE nghĩa là đầu ra thật đã vượt hard gates; xong thì dừng.

## Quy trình

### Bước 1 — Khóa mục tiêu

Tự xác định:
- doanh nghiệp mục tiêu và website chính;
- mục đích đọc: hiểu doanh nghiệp / học mô hình / xem đối thủ / chuẩn bị hợp tác;
- chế độ REPORT_ONLY hay LANDING_AND_PUBLISH;
- ngày cập nhật;
- phạm vi nguồn công khai;
- điều Owner không muốn: thuật ngữ khó, PR, suy đoán, phán quyết thiếu căn cứ.

Không hỏi lại nếu tên công ty hoặc website đã đủ rõ.
### Bước 2 — Xác minh đúng doanh nghiệp

Tìm và đối chiếu:
- tên pháp lý;
- tên thương hiệu;
- mã số thuế / số đăng ký nếu có;
- ngày hoạt động;
- người đại diện;
- địa chỉ;
- website và các kênh chính thức;
- công ty/cá nhân liên quan có khả năng gây nhầm lẫn.

Nếu có nhiều pháp nhân hoặc tên gần giống, lập bảng quan hệ và ghi rõ phần nào chưa xác minh được.

### Bước 3 — Bóc toàn bộ dấu vết công khai

Tìm có mục tiêu, không thu thập vô hạn:
- website chính thức và các trang con;
- cửa hàng / sản phẩm / bảng giá;
- trang tuyển dụng;
- bài báo;
- mạng xã hội khi hữu ích;
- dữ liệu đăng ký doanh nghiệp;
- cơ quan quản lý / danh sách giấy phép khi liên quan;
- bài nghiên cứu gốc khi có claim khoa học;
- đối tác, nhà máy, đơn vị chịu trách nhiệm chất lượng;
- khóa học, nhượng quyền, đại lý, cộng đồng, sự kiện;
- app, sàn thương mại điện tử hoặc kênh bán.

Dừng mở rộng nguồn khi nguồn mới không còn thay đổi kết luận quan trọng hoặc độ không chắc chắn.

### Bước 4 — Lập bản đồ cách doanh nghiệp sống bằng tiền

Không chỉ liệt kê sản phẩm. Phải trả lời:
- Ai trả tiền?
- Trả tiền cho thứ gì?
- Món đầu tiên kéo người vào hệ thống là gì?
- Món nào giá trị cao?
- Món nào có thể mua lại?
- Có đào tạo / nhượng quyền / máy móc / dịch vụ / membership / đại lý không?
- Một khách hoặc đối tác có thể tạo nhiều lần mua theo chuỗi nào?
- Công ty mở rộng bằng cửa hàng, đội bán hàng, cộng đồng, quảng cáo, đối tác hay nhượng quyền?
### Bước 5 — Tách 3 lớp sự thật

Mỗi phát hiện quan trọng gắn một lớp:

- **ĐÃ XÁC MINH**: nguồn độc lập hoặc nguồn gốc phù hợp xác nhận dữ kiện.
- **CÔNG TY CÔNG BỐ**: doanh nghiệp tự nói, bài doanh nghiệp giới thiệu, tài liệu bán hàng.
- **NHẬN ĐỊNH**: suy luận của báo cáo từ nhiều dữ kiện.

Không lạm dụng nhãn trên từng câu nếu làm khó đọc; nhãn phải xuất hiện ở nơi có nguy cơ người đọc nhầm mức độ chắc chắn.

### Bước 6 — Mở nhánh chuyên sâu theo ngành

Chỉ mở khi liên quan:

**Sức khỏe / thực phẩm / mỹ phẩm / thiết bị**
- kiểm tra công dụng đang quảng bá;
- loại hồ sơ/đăng ký công khai nếu tìm được;
- nghiên cứu khoa học gốc;
- bằng chứng có đúng sản phẩm, đúng nhóm người, đúng cách dùng không;
- phản ứng bất lợi / giới hạn / mâu thuẫn.

**Đào tạo**
- ai tổ chức;
- loại giấy nhận được;
- ai có thẩm quyền cấp;
- tránh đánh đồng chứng nhận học xong với giấy phép hành nghề.

**Nhượng quyền / đại lý / đội nhóm**
- số điểm đang hoạt động thực;
- số đã đóng nếu có;
- phí / điều kiện / mua tối thiểu;
- cách trả thưởng;
- phân biệt mục tiêu, số ký kết, số đang hoạt động.

**Công nghệ**
- mô tả công nghệ chung khác với bằng chứng trên sản phẩm cụ thể;
- tìm nghiên cứu, tiêu chuẩn, giới hạn và điều kiện sử dụng thực tế.
### Bước 7 — Tìm “những gì chưa được nói ra”

Bắt buộc tạo danh sách dữ liệu còn thiếu, ưu tiên:
- doanh thu;
- lợi nhuận;
- tiền thực thu và thực chi;
- doanh thu theo sản phẩm/kênh;
- số khách mua thật;
- tỷ lệ khách quay lại;
- chi phí có một khách mới;
- số đại lý/cơ sở đang hoạt động;
- tỷ lệ đóng cửa;
- thời gian hoàn vốn;
- thu nhập người tham gia sau chi phí;
- hàng tồn kho;
- khiếu nại / trả hàng;
- cổ đông / quyền quyết định;
- hợp đồng / giấy phép / nghiên cứu gốc.

Từ khoảng trống này sinh **20–30 câu hỏi cần hỏi thêm**. Câu hỏi phải đời thường, cụ thể, trả lời được bằng số hoặc tài liệu.

### Bước 8 — Phản biện

Tự kiểm tra:
- Có đang vô tình viết PR không?
- Có coi độ phủ truyền thông là quy mô thật không?
- Có tin lời người bán hơn hồ sơ gốc không?
- Có suy một nghiên cứu nhỏ thành công dụng rộng không?
- Có nhầm “đăng ký ngành” với “được phép làm mọi hoạt động trong ngành” không?
- Có nhầm số ký kết với số đang hoạt động không?
- Có thiếu phương án giải thích khác cho cùng một dữ kiện không?

Khi hệ quả lớn, dùng logic của `skills/decision-challenger/SKILL.md` để thử bác bỏ kết luận đang dẫn đầu.
### Bước 9 — Viết cho sếp đọc là hiểu

Áp dụng `references/OWNER_LANGUAGE_RULES.md`.

Bắt buộc:
- kết luận trước;
- câu ngắn;
- một đoạn một ý;
- tiếng Việt là chính;
- không dùng tiếng Anh để tạo vẻ chuyên nghiệp;
- tên riêng/tên sản phẩm giữ nguyên nếu cần;
- từ chuyên môn bắt buộc phải giải nghĩa ngay;
- tiêu đề trả lời câu hỏi đời thường: “Công ty là ai?”, “Kiếm tiền bằng cách nào?”, “Điểm cần chú ý là gì?”;
- không bắt người đọc phải biết tài chính, marketing, công nghệ, pháp lý hay nghiên cứu.

### Bước 10 — Thích nghi thiết kế thương hiệu

Chỉ với LANDING_AND_PUBLISH.

Đọc website mục tiêu để rút ra:
- màu chính/phụ;
- nền sáng/tối;
- kiểu chữ;
- mật độ nội dung;
- ảnh và họa tiết;
- góc bo / nét viền;
- cảm giác: cao cấp, Đông phương, kỹ thuật, tối giản, trẻ, dược liệu, thời trang...
- cách dùng khoảng trắng;
- nhịp khối nội dung.

Sau đó chọn **một hướng thiết kế chính**.
Học “ngôn ngữ thiết kế”, không copy logo, ảnh, bố cục hay mã nguồn nguyên xi.
Khi cần, dùng `skills/web-design-intelligence/SKILL.md` như lớp hỗ trợ.

### Bước 11 — Dựng landing

Khung lõi mặc định:
1. Kết luận nhanh.
2. 4–6 con số đáng chú ý.
3. Điều phải nói rõ về giới hạn dữ liệu.
4. Công ty là ai.
5. Công ty bán gì.
6. Công ty kiếm tiền bằng cách nào.
7. Cách công ty mở rộng.
8. Thương hiệu và truyền thông.
9. Nhánh chuyên sâu theo ngành.
10. Điểm mạnh.
11. Điểm cần chú ý.
12. Điều đáng học.
13. 20–30 câu cần hỏi thêm.
14. Nhận định cuối.
15. Nguồn đã dùng.

Không ép mọi doanh nghiệp phải có đúng 15 mục; bỏ mục không có giá trị và mở thêm mục khi ngành yêu cầu.
### Bước 12 — QA bắt buộc

Chạy 6 bước kiểm tra:

**QA-1 Sự thật**
- câu nào nói mạnh hơn nguồn?
- số nào không có nguồn?
- mục tiêu có bị viết thành kết quả?

**QA-2 Mức độ chắc chắn**
- “đã xác minh / công ty công bố / nhận định” có bị trộn không?

**QA-3 Phản biện**
- có điểm bất lợi quan trọng nào bị bỏ qua?
- có câu nào giống PR?

**QA-4 Ngôn ngữ**
- quét toàn bộ chữ hiển thị, kể cả menu, nút, nhãn, chú thích, bảng, nguồn;
- tìm tiếng Anh, viết tắt và từ chuyên môn;
- thay bằng từ phổ thông hoặc giải thích ngay;
- proper name được giữ nhưng không dùng làm thuật ngữ giải thích.

**QA-5 Thiết kế**
- có thực sự mang cảm giác của thương hiệu mục tiêu không?
- có dễ đọc trên điện thoại không?
- có copy quá sát website gốc không?

**QA-6 Bản web đang chạy**
- kiểm tra repo có file đúng;
- kiểm tra pipeline/deploy thành công;
- kiểm tra URL thật sau deploy;
- nếu người dùng có thể nhận cache cũ, thêm version query khi gửi link;
- không báo DONE khi deploy còn pending.

### Bước 13 — Đóng gói và trả Owner

REPORT_ONLY:
- báo cáo + nguồn;
- không publish nếu Owner chưa yêu cầu.

LANDING_AND_PUBLISH:
- landing chạy thật;
- repo public nếu Owner yêu cầu/publication scope đã được gọi rõ;
- trả link landing trước, repo sau;
- 3–5 phát hiện quan trọng nhất;
- không kể lể quy trình/tool call.
## Progressive references

Luôn đọc:
- `organization/OWNER_COMMUNICATION_STANDARD_V1.md`
- `references/COMPANY_ANALYSIS_FRAMEWORK.md`
- `references/EVIDENCE_POLICY.md`
- `references/OWNER_LANGUAGE_RULES.md`

Chỉ đọc khi LANDING_AND_PUBLISH:
- `references/BRAND_ADAPTIVE_LANDING.md`
- `skills/web-design-intelligence/SKILL.md`

Chỉ đọc khi cần phản biện sâu:
- `skills/decision-challenger/SKILL.md`

Chỉ đọc khi cần nghiên cứu liên ngành hoặc nguồn khó:
- `skills/research-new-feature/SKILL.md`

## Quyền và giới hạn

Skill có thể yêu cầu khả năng:
- web search/read;
- tra cứu GitHub;
- đọc website và tài liệu công khai;
- tạo file web;
- kiểm tra deploy.

Skill **không tự cấp quyền**:
- publish ra ngoài nếu Owner chưa yêu cầu chế độ có publish;
- sửa website doanh nghiệp mục tiêu;
- đăng bài, nhắn tin, mua hàng;
- truy cập tài khoản riêng;
- khẳng định dữ liệu nội bộ không nhìn thấy.

## Definition of Done

REPORT_ONLY chỉ DONE khi:
- đúng doanh nghiệp;
- nguồn đủ để hỗ trợ các kết luận quan trọng;
- 3 lớp sự thật rõ;
- cách kiếm tiền và mở rộng được giải thích;
- khoảng trống dữ liệu + câu hỏi cần hỏi thêm đầy đủ;
- ngôn ngữ qua Owner readability gate.

LANDING_AND_PUBLISH chỉ DONE khi thêm:
- landing phù hợp ngôn ngữ thương hiệu;
- mobile readable;
- nguồn bấm được;
- deploy thành công;
- URL thật mở được sau lần cập nhật cuối;
- không còn thuật ngữ khó không giải thích trong chữ hiển thị.

## Stop condition

Khi deliverable đã vượt hard gates và đã giao link/report cho Owner: **DONE MEANS STOP**.