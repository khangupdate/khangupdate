# skill Phân Tích Doanh Nghiệp

Technical ID: `phan-tich-doanh-nghiep`

## Dùng nhanh

Ví dụ mặc định:

`Dùng skill Phân Tích Doanh Nghiệp phân tích https://congtyabc.vn`

Chỉ câu này là đủ để chạy trọn quy trình và trả landing + repo public + link xem thật.

Nếu chỉ muốn nghiên cứu trước:

`Dùng skill Phân Tích Doanh Nghiệp phân tích Công ty ABC. Chỉ báo cáo, chưa làm web.`

## Skill tự làm

- xác minh đúng doanh nghiệp;
- tìm nguồn công khai;
- bóc sản phẩm và nguồn thu;
- giải thích cách mở rộng;
- kiểm tra nghiên cứu/pháp lý khi cần;
- tách ĐÃ XÁC MINH / CÔNG TY CÔNG BỐ / NHẬN ĐỊNH;
- tìm dữ liệu còn thiếu;
- sinh 20–30 câu cần hỏi thêm;
- viết theo chuẩn “sếp đọc là hiểu”;
- thích nghi thiết kế theo website mục tiêu;
- kiểm tra deploy thật nếu có xuất bản.

## Trạng thái

CANDIDATE — đã có hai ca seed trước khi đóng gói (Love World, Thiên Bách Thảo). Có thể dùng khi Owner gọi rõ tên Skill. Cần thêm một ca live A/B sau đóng gói trước khi đề xuất ACTIVE.