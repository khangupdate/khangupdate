#!/usr/bin/env python3
import argparse, re, sys
from pathlib import Path

DEFAULT_TERMS = {
    "business model":"cách công ty kiếm tiền / cách kinh doanh",
    "revenue stream":"nguồn thu",
    "gross margin":"sau khi trừ chi phí làm ra hoặc nhập sản phẩm còn bao nhiêu tiền",
    "retention":"khách có quay lại mua tiếp không",
    "customer acquisition cost":"để có một khách mới phải tốn bao nhiêu tiền",
    "governance":"cách kiểm soát",
    "claim":"lời quảng cáo / điều doanh nghiệp nói",
    "due diligence":"những điều cần kiểm tra kỹ trước khi quyết định",
    "distribution":"mạng lưới bán hàng / cách đưa sản phẩm ra thị trường",
    "funnel":"các bước từ biết đến mua",
    "flywheel":"vòng lặp giúp công ty tiếp tục tăng trưởng",
    "unit economics":"một khách / điểm / đơn có thực sự tạo ra tiền hay không",
    "churn":"khách hoặc đối tác rời hệ thống",
    "sku":"sản phẩm / mã sản phẩm",
    "founder-led":"phụ thuộc nhiều vào người sáng lập",
    "commercial engine":"cách công ty tạo doanh thu",
    "science signal":"tín hiệu từ nghiên cứu",
    "effect size":"mức thay đổi thực tế",
    "stress-test":"phép thử thực tế",
    "blind spot":"điểm còn thiếu / chưa nhìn thấy",
    "public footprint":"dấu vết công khai",
    "active agents":"người bán đang thực sự hoạt động",
    "network effects":"càng nhiều người tham gia thì hệ thống càng có lợi thế",
}

def visible_text(raw: str) -> str:
    raw = re.sub(r"<script\b[^>]*>[\s\S]*?</script>", " ", raw, flags=re.I)
    raw = re.sub(r"<style\b[^>]*>[\s\S]*?</style>", " ", raw, flags=re.I)
    raw = re.sub(r"<[^>]+>", " ", raw)
    raw = re.sub(r"&[A-Za-z0-9#]+;", " ", raw)
    return re.sub(r"\s+", " ", raw).strip()

def main():
    ap = argparse.ArgumentParser(description="Scan visible report text for owner-unfriendly jargon.")
    ap.add_argument("path")
    ap.add_argument("--allow", action="append", default=[], help="Exact term allowed as a proper name.")
    args = ap.parse_args()
    p = Path(args.path)
    text = visible_text(p.read_text(encoding="utf-8"))
    lower = text.lower()
    allowed = {x.lower() for x in args.allow}
    hits = []
    for term, replacement in DEFAULT_TERMS.items():
        if term in allowed:
            continue
        if re.search(r"(?<![\w-])" + re.escape(term) + r"(?![\w-])", lower, flags=re.I):
            hits.append((term, replacement))
    if hits:
        print("OWNER_LANGUAGE_SCAN=FAIL")
        for term, repl in hits:
            print(f"- {term} -> {repl}")
        sys.exit(2)
    print("OWNER_LANGUAGE_SCAN=PASS")

if __name__ == "__main__":
    main()