# Landing thích nghi theo thương hiệu

Mục tiêu: báo cáo phải có cảm giác cùng “thế giới hình ảnh” với doanh nghiệp mục tiêu, nhưng vẫn là một báo cáo độc lập.

## 1. Đọc website trước khi thiết kế

Thu thập:
- 3–5 màu xuất hiện nhiều;
- nền sáng hay tối;
- font cảm giác hiện đại / cổ điển / mềm / kỹ thuật;
- ảnh người, sản phẩm, thiên nhiên, máy móc hay đồ họa;
- họa tiết đặc trưng;
- nút tròn hay vuông;
- đường viền / shadow / gradient;
- mật độ chữ;
- tỷ lệ khoảng trắng;
- cảm giác tổng thể.

## 2. Chọn một hướng chính

Ví dụ:
- Đông phương / thảo dược → xanh, vàng, kem, serif, họa tiết nhẹ;
- công nghệ → tối, lưới, chữ sans, dữ liệu;
- thời trang cao cấp → nhiều khoảng trắng, editorial, ảnh lớn;
- FMCG trẻ → màu sáng, card rõ, hình sản phẩm.

Không ghép nhiều phong cách không liên quan.
## 3. Học ngôn ngữ, không sao chép

Được:
- học bảng màu;
- học độ sang/trẻ/kỹ thuật;
- học nhịp khoảng trắng;
- học cách dùng hình ảnh;
- học chất liệu trang trí.

Không:
- copy nguyên HTML/CSS;
- copy bố cục từng section;
- lấy ảnh/logo không cần thiết;
- giả làm website chính thức của doanh nghiệp;
- dùng tên miền hoặc nhận diện khiến người xem hiểu nhầm đây là trang của doanh nghiệp.

Landing phải ghi rõ là báo cáo phân tích độc lập từ nguồn công khai.

## 4. Cấu trúc đọc trên điện thoại

- headline không quá dài;
- chữ thân bài đủ lớn;
- card 1 cột khi màn hình hẹp;
- bảng phải chuyển được sang dạng dễ đọc;
- không bắt kéo ngang;
- menu có thể ẩn trên mobile;
- nguồn vẫn bấm được.

## 5. Thiết kế phục vụ nội dung

Màu và trang trí không được làm lu mờ:
- nhãn ĐÃ XÁC MINH;
- CÔNG TY CÔNG BỐ;
- NHẬN ĐỊNH;
- cảnh báo dữ liệu thiếu;
- câu hỏi cần hỏi thêm.

## 6. Kiểm tra cuối

So landing với website mục tiêu:
- có cùng cảm giác không?
- có đủ khác để không bị hiểu nhầm là copy/chính thức không?
- có dễ đọc hơn website gốc ở vai trò “báo cáo cho sếp” không?