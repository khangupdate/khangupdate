# Khung phân tích doanh nghiệp

Mục tiêu của khung này là buộc báo cáo trả lời được câu hỏi kinh doanh thật, không dừng ở việc chép “Giới thiệu công ty”.

## 1. Công ty là ai?

Tối thiểu kiểm tra:
- tên pháp lý và tên thương hiệu;
- ngày bắt đầu hoạt động;
- người đại diện;
- địa chỉ;
- ngành nghề chính;
- các pháp nhân hoặc thương hiệu liên quan;
- người sáng lập / lãnh đạo khi có nguồn;
- mâu thuẫn giữa giấy tờ và truyền thông nếu có.

## 2. Công ty bán gì?

Lập danh mục:
- sản phẩm vật lý;
- dịch vụ;
- máy móc;
- khóa học;
- gói thành viên;
- nhượng quyền / đại lý;
- phần mềm / nền tảng;
- sản phẩm mua một lần;
- sản phẩm có khả năng mua lại.
## 3. Công ty kiếm tiền thế nào?

Phải trả lời theo chuỗi:
1. Ai trả tiền?
2. Trả cho thứ gì?
3. Mức giá công khai là bao nhiêu?
4. Có bước bán tiếp nào sau giao dịch đầu tiên?
5. Có doanh thu lặp lại không?
6. Có doanh thu từ đối tác thay vì khách cuối không?
7. Có nguồn thu nào phụ thuộc mạnh vào tuyển người / mở điểm / mở đại lý không?

Không được suy số doanh thu nếu không có dữ liệu.

## 4. Công ty mở rộng thế nào?

Tìm:
- cửa hàng trực tiếp;
- đại lý;
- đội bán hàng;
- cộng đồng;
- người giới thiệu;
- sàn thương mại điện tử;
- quảng cáo;
- nhượng quyền;
- đào tạo người mới;
- đối tác doanh nghiệp;
- xuất khẩu.

Phân biệt rõ:
- mục tiêu;
- số đã ký;
- số từng hoạt động;
- số đang hoạt động.
## 5. Điều gì tạo niềm tin?

Ví dụ:
- người sáng lập;
- bác sĩ/chuyên gia;
- nghiên cứu;
- chứng nhận;
- nhà máy;
- đối tác;
- báo chí;
- câu chuyện khách hàng;
- cộng đồng;
- sự kiện;
- lịch sử thương hiệu.

Sau đó kiểm tra mức bằng chứng thật của từng lớp.

## 6. Điều gì giữ khách?

Tìm tín hiệu về:
- mua lại;
- thành viên;
- liệu trình;
- sản phẩm dùng thường xuyên;
- câu lạc bộ;
- chăm sóc sau bán;
- cộng đồng;
- ưu đãi;
- khóa học tiếp theo.

Nếu không có dữ liệu giữ khách, ghi CHƯA RÕ.

## 7. Điều gì có thể là nút thắt?

Xem:
- phụ thuộc một sản phẩm;
- phụ thuộc một người sáng lập;
- chất lượng không đồng đều khi mở rộng;
- kiểm soát người bán;
- công dụng quảng cáo;
- giấy phép;
- hàng tồn kho;
- khả năng tuyển người;
- chi phí mặt bằng;
- phụ thuộc nhà máy / nhà cung cấp.
## 8. Điều gì đáng học?

Không viết chung chung “thương hiệu tốt”.

Phải chỉ ra cơ chế:
- cách họ đóng gói sản phẩm;
- cách biến đào tạo thành kênh mở rộng;
- cách tạo nhiều lần mua;
- cách biến cộng đồng thành kênh bán;
- cách tạo bằng chứng / niềm tin;
- cách chuẩn hóa để mở nhiều điểm.

## 9. Câu hỏi phải hỏi thêm

Câu hỏi tốt phải:
- trả lời được bằng số, tài liệu hoặc yes/no rõ;
- làm thay đổi nhận định nếu câu trả lời khác nhau;
- không hỏi những thứ đã có nguồn rõ;
- ưu tiên doanh thu, lợi nhuận, khách thật, mua lại, điểm đang hoạt động, hoàn vốn, giấy phép, sở hữu, chất lượng và rủi ro.

## 10. Kết luận cuối

Không chấm “công ty tốt/xấu”.

Kết luận nên nói:
- mô hình đang dựa vào điều gì;
- lợi thế nhìn thấy;
- điểm chưa chứng minh;
- điều gì phải có thêm dữ liệu mới biết;
- ý nghĩa nếu Owner đang học mô hình / hợp tác / cạnh tranh.