# Quy chuẩn ngôn ngữ — Sếp đọc là hiểu

Mục tiêu: một người làm kinh doanh không cần biết tài chính, marketing, công nghệ, nghiên cứu hay pháp lý vẫn hiểu ngay nội dung.

## Luật

1. Câu ngắn.
2. Một đoạn một ý.
3. Kết luận trước, giải thích sau.
4. Tiếng Việt trước.
5. Không dùng tiếng Anh để tạo cảm giác chuyên nghiệp.
6. Tên riêng / tên sản phẩm / tên công nghệ có thể giữ nguyên.
7. Từ chuyên môn bắt buộc phải giải thích ngay trong cùng câu.
8. Tiêu đề phải trả lời câu hỏi thực tế.
9. Không dùng chữ viết tắt nếu người đọc có thể không biết.
10. Nếu một từ có cách nói đời thường tương đương, dùng cách đời thường.

## Bản dịch ý nghĩa ưu tiên

- business model → cách công ty kiếm tiền / cách kinh doanh
- revenue stream → nguồn thu
- gross margin → sau khi trừ chi phí làm ra hoặc nhập sản phẩm còn bao nhiêu tiền
- retention → khách có quay lại mua tiếp không
- acquisition cost → để có một khách mới phải tốn bao nhiêu tiền
- governance → cách kiểm soát
- channel governance → cách kiểm soát người bán và nơi bán
- claim → lời quảng cáo / điều doanh nghiệp nói về công dụng
- due diligence → những điều cần kiểm tra kỹ trước khi quyết định
- distribution → cách đưa sản phẩm ra thị trường / mạng lưới bán hàng
- funnel → các bước từ biết đến mua
- flywheel → vòng lặp giúp công ty tiếp tục tăng trưởng
- unit economics → một khách / một điểm / một đơn hàng có thực sự tạo ra tiền hay không
- churn → khách hoặc đối tác ngừng sử dụng / rời hệ thống
- SKU → sản phẩm / mã sản phẩm
- founder-led → phụ thuộc nhiều vào người sáng lập
## Farmer Test

Trước khi DONE, hỏi:

> Một người chưa từng học kinh doanh có hiểu đoạn này trong một lần đọc không?

Nếu không:
- đổi từ;
- tách câu;
- thêm ví dụ;
- nói “điều này có nghĩa là gì”.

## Quét toàn bộ giao diện

Không chỉ kiểm tra thân bài.

Phải quét:
- tiêu đề trang;
- menu;
- nút;
- nhãn;
- thẻ số liệu;
- tên cột bảng;
- chú thích;
- cảnh báo;
- phần nguồn;
- footer;
- metadata hiển thị nếu có.

## Ngoại lệ

Có thể giữ:
- tên doanh nghiệp;
- tên người;
- tên sản phẩm;
- tên tạp chí / cơ quan;
- tên công nghệ;
- mã số;
- đường dẫn.

Nhưng nếu tên công nghệ có vai trò trong lập luận, phải giải thích nó bằng tiếng Việt.

## Gate cuối

Nếu Owner/sếp có khả năng phải hỏi “từ này nghĩa là gì?” để hiểu kết luận, output chưa đạt.