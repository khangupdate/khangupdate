# Bài học từ hai ca mẫu trước khi đóng gói Skill

## Ca 1 — Love World

Điều có giá trị:
- không dừng ở sản phẩm, mà bóc ra hệ thống sản phẩm + cộng đồng + người bán + lớp khoa học;
- tách rõ công ty tự công bố và phần đã xác minh;
- không dùng số bài báo để suy ra quy mô;
- nhận ra cần kiểm tra cách trả thưởng thay vì gắn nhãn mô hình chỉ từ chữ “đội nhóm”;
- đọc nghiên cứu gốc thay vì chỉ đọc bài truyền thông.

Lỗi đã xảy ra:
- bản đầu dùng quá nhiều từ như governance, retention, gross margin, effect size;
- repo đã sửa nhưng người dùng vẫn thấy bản web cũ vì deploy chưa xong.

Bài học khóa cứng:
- quét toàn bộ chữ hiển thị;
- deploy pending = chưa DONE;
- link cuối nên dùng phiên bản mới nhất sau khi xác minh.

## Ca 2 — Thiên Bách Thảo

Điều có giá trị:
- nhận ra công ty bán cả bộ máy + sản phẩm + đào tạo + thương hiệu + cách mở điểm;
- phân biệt số cơ sở đang liệt kê, số đại lý từng công bố và mục tiêu tương lai;
- tách nghiên cứu chung về Terahertz khỏi bằng chứng cho một máy cụ thể;
- phát hiện cách gọi “chứng chỉ hành nghề” cần kiểm tra loại giấy và đơn vị cấp;
- dùng ngôn ngữ thiết kế xanh ngọc + vàng + chất liệu Đông phương thay vì dùng lại giao diện Love World.

Bài học khóa cứng:
- mỗi doanh nghiệp phải có thiết kế riêng dựa trên website gốc;
- nhánh khoa học/pháp lý chỉ mở khi ngành cần;
- “có công nghệ” không đồng nghĩa “mọi công dụng của sản phẩm đã được chứng minh”.

## Giá trị tái sử dụng

Hai ca có ngành, cách bán và ngôn ngữ thương hiệu khác nhau nhưng cùng dùng được một lõi:
1. xác minh đúng doanh nghiệp;
2. bóc sản phẩm và cách kiếm tiền;
3. tìm cách mở rộng;
4. phân tầng bằng chứng;
5. tìm điểm chưa biết;
6. viết câu hỏi cần hỏi thêm;
7. viết lại cho sếp đọc là hiểu;
8. thích nghi thiết kế;
9. kiểm tra bản web thật.

Đây là bằng chứng về **repeatability**, nhưng chưa phải A/B chính thức của Skill sau khi đóng gói.