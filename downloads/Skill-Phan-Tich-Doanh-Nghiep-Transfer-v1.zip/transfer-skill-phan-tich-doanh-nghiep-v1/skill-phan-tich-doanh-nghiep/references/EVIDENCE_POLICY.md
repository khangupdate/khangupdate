# Chính sách bằng chứng

## Ba lớp thông tin

### ĐÃ XÁC MINH
Dùng khi nguồn phù hợp có thể xác nhận dữ kiện.

Ví dụ:
- dữ liệu đăng ký doanh nghiệp cho tên, ngày hoạt động, người đại diện;
- trang sản phẩm chính thức cho giá đang niêm yết;
- bài nghiên cứu gốc cho thiết kế và kết quả nghiên cứu;
- cơ quan quản lý cho trạng thái giấy phép / yêu cầu kiểm tra.

### CÔNG TY CÔNG BỐ
Dùng khi thông tin đến từ:
- website doanh nghiệp;
- tài liệu bán hàng;
- bài “doanh nghiệp giới thiệu”;
- phát biểu của lãnh đạo;
- sự kiện do doanh nghiệp tự đăng.

Thông tin này có thể đúng, nhưng nguồn chỉ chứng minh rằng doanh nghiệp đang nói điều đó.

### NHẬN ĐỊNH
Là phần hệ thống rút ra từ nhiều dữ kiện.
Không trình bày nhận định như dữ kiện.
## Quy tắc theo loại nguồn

**Đăng ký doanh nghiệp**
- tốt cho tên, mã số, người đại diện, ngành đăng ký;
- không chứng minh doanh nghiệp đang thực sự làm tất cả ngành đã đăng ký;
- không chứng minh quyền cấp giấy phép/chứng chỉ cụ thể.

**Website doanh nghiệp**
- tốt cho sản phẩm, giá, thông điệp, cách công ty tự mô tả;
- không đủ để xác nhận hiệu quả, quy mô, lợi nhuận hay chất lượng độc lập.

**Báo chí**
- kiểm tra xem bài là báo chí tự biên tập hay nội dung doanh nghiệp giới thiệu;
- không dùng độ phủ báo chí thay cho doanh thu.

**Nghiên cứu khoa học**
- đọc nghiên cứu gốc khi có thể;
- kiểm tra đúng sản phẩm, đúng đối tượng, đúng thời gian, đúng kết quả;
- ghi cả độ lớn kết quả và giới hạn;
- funding không làm nghiên cứu tự động sai, nhưng phải được biết khi đánh giá mức độc lập.

**Cơ quan quản lý**
- yêu cầu kiểm tra != kết luận vi phạm;
- chưa thấy kết luận cuối phải giữ trạng thái chưa rõ.
## Các lỗi cấm

- “mục tiêu 1.000 điểm” → “có 1.000 điểm”.
- “hiện diện 20 nước” → “có doanh thu lớn ở 20 nước”.
- “có bài nghiên cứu” → “mọi quảng cáo đều được chứng minh”.
- “công nghệ X có nghiên cứu” → “thiết bị Y dùng X chắc chắn có hiệu quả”.
- “đăng ký ngành đào tạo” → “được quyền cấp chứng chỉ hành nghề”.
- “có nhiều người đăng ký” → “có nhiều người đang hoạt động”.
- “có nhiều review” → “khách hàng hài lòng toàn hệ thống”.

## Khi nguồn mâu thuẫn

1. Không xóa mâu thuẫn.
2. Ghi nguồn nào nói gì.
3. Ưu tiên nguồn có thẩm quyền đúng với loại claim.
4. Nếu chưa thể phân xử: ghi **CHƯA RÕ**.
5. Tạo câu hỏi kiểm tra để giải quyết mâu thuẫn.

## Khi không tìm thấy dữ liệu

Không dùng model memory để điền số.
Không suy từ dữ liệu ngành sang công ty cụ thể.
Không suy từ số sự kiện sang số khách.
Không suy từ số nhân sự tuyển dụng sang doanh thu.