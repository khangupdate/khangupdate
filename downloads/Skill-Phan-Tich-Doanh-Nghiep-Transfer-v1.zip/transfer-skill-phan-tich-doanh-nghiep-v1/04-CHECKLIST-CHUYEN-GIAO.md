# Checklist chuyển giao

- [ ] Khách đăng nhập ChatGPT.
- [ ] Khách có GitHub.
- [ ] Tạo repo chứa Skill.
- [ ] Upload nguyên thư mục `skill-phan-tich-doanh-nghiep`.
- [ ] Kết nối GitHub với ChatGPT.
- [ ] ChatGPT đọc được `SKILL.md`.
- [ ] Dán prompt cài đặt.
- [ ] Test 1 công ty ở chế độ chỉ báo cáo.
- [ ] Test quyền tạo/sửa repo xuất landing nếu khách cần publish.
- [ ] Gửi cho khách câu lệnh sử dụng hằng ngày.

## Tiêu chuẩn bàn giao thành công
Khách có thể dùng điện thoại và chỉ cần gửi:

`Dùng skill Phân Tích Doanh Nghiệp phân tích <website>`

Không cần Terminal. Không cần biết code.
