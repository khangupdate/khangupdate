# Bộ chuyển giao — skill Phân Tích Doanh Nghiệp

Đây là package để chuyển giao nhanh cho khách hàng dùng ChatGPT + GitHub.

Bắt đầu tại: `00-BAT-DAU-5-PHUT.md`

## File quan trọng
- `01-PROMPT-CAI-DAT.txt`: dán một lần sau khi kết nối GitHub.
- `02-PROMPT-SU-DUNG.txt`: câu lệnh dùng hằng ngày.
- `03-PROMPT-CHI-BAO-CAO.txt`: chỉ nghiên cứu, không publish.
- `04-CHECKLIST-CHUYEN-GIAO.md`: checklist cho người cài đặt.
- `skill-phan-tich-doanh-nghiep/`: Skill đầy đủ.

Không chứa token, mật khẩu hoặc thông tin đăng nhập.
