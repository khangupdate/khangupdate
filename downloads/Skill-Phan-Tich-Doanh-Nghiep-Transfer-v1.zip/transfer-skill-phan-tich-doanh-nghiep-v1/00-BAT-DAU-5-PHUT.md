# Chuyển giao skill Phân Tích Doanh Nghiệp trong 5 phút

## Khách hàng cần
1. Tài khoản ChatGPT.
2. Tài khoản GitHub.
3. GitHub đã kết nối với ChatGPT qua Plugin/connector.
4. ChatGPT có khả năng tìm web để nghiên cứu nguồn công khai.

## Cài đặt nhanh

### Phút 1 — Tạo repo
Tạo một repo GitHub mới, ví dụ: `phan-tich-doanh-nghiep`.

Repo có thể public. Không đưa token, mật khẩu hoặc dữ liệu mật vào repo.

### Phút 2 — Đưa Skill lên GitHub
Upload nguyên thư mục `skill-phan-tich-doanh-nghiep/`.

Không đổi tên `SKILL.md`.

### Phút 3 — Kết nối GitHub
Kết nối GitHub của khách với ChatGPT. Cấp quyền đúng repo chứa Skill và repo dùng để xuất landing.

### Phút 4 — Dán prompt cài đặt
Mở `01-PROMPT-CAI-DAT.txt`, thay `OWNER/REPO` bằng repo thật rồi gửi cho ChatGPT một lần.

### Phút 5 — Test
Gửi:
`Dùng skill Phân Tích Doanh Nghiệp phân tích https://example.com. Chỉ báo cáo, chưa publish.`

Nếu ChatGPT đọc đúng SKILL.md, tách rõ ĐÃ XÁC MINH / CÔNG TY CÔNG BỐ / NHẬN ĐỊNH và viết tiếng Việt dễ hiểu thì setup đạt.

## Dùng hằng ngày
Chỉ cần:
`Dùng skill Phân Tích Doanh Nghiệp phân tích https://tencongty.com`

Mặc định Skill sẽ nghiên cứu, tạo landing, đưa lên GitHub và trả link nếu ChatGPT hiện tại có đủ quyền/công cụ.

## Lưu ý
- Nếu muốn chỉ nghiên cứu: thêm `Chỉ báo cáo, chưa làm web.`
- Nếu mở một chat hoàn toàn mới và ChatGPT không còn ngữ cảnh cài đặt, dán lại prompt cài đặt.
- Cách chắc chắn nhất là giữ một cuộc chat riêng cho Skill hoặc đặt prompt cài đặt vào phần hướng dẫn cố định của không gian làm việc/GPT mà khách sử dụng.
- GitHub chứa Skill và landing. ChatGPT là nơi thực hiện công việc.
